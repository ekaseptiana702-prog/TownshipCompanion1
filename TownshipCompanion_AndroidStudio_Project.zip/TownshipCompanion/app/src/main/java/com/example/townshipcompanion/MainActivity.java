package com.example.townshipcompanion;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private final String[] names = {"Coins", "Township Cash", "Gems"};
    private final String[] keys = {"coins", "cash", "gems"};
    private final int[] icons = {0x1F4B0, 0x1F4B5, 0x1F48E};
    private final int[] colors = {0xFFFFD166, 0xFF78D6A3, 0xFFB9A0FF};
    private long[] balances = {250000, 5000, 2500};
    private TextView[] balanceViews = new TextView[3];
    private SharedPreferences prefs;
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("local_wallet_demo", MODE_PRIVATE);
        for (int i = 0; i < 3; i++) balances[i] = prefs.getLong(keys[i], balances[i]);
        buildUi();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(238, 246, 231));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 22, 22, 28);
        scroll.addView(root);
        setContentView(scroll);

        TextView header = text("🌳  TOWNSHIP COMPANION", 22, Color.WHITE, true);
        header.setPadding(20, 22, 20, 8);
        TextView sub = text("LOCAL WALLET • SIMULATOR", 12, 0xFFE7F5E9, true);
        sub.setPadding(20, 0, 20, 18);
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setBackground(bg(0xFF286348, 26));
        hero.addView(header); hero.addView(sub);
        root.addView(hero, matchWrap());

        TextView note = text("Demo saldo lokal — tidak terhubung ke Township, tidak mengubah akun atau server game.", 13, 0xFF66552F, false);
        note.setPadding(14, 14, 14, 14);
        note.setBackground(bg(0xFFFFF0C9, 16));
        LinearLayout.LayoutParams np = matchWrap(); np.topMargin = 16;
        root.addView(note, np);

        TextView title = text("Dompet simulasi", 20, 0xFF234B38, true);
        LinearLayout.LayoutParams tp = matchWrap(); tp.topMargin = 22; tp.bottomMargin = 8;
        root.addView(title, tp);

        for (int i = 0; i < 3; i++) addWalletCard(i);

        TextView tools = text("Kelola saldo demo", 18, 0xFF234B38, true);
        LinearLayout.LayoutParams toolp = matchWrap(); toolp.topMargin = 22; toolp.bottomMargin = 8;
        root.addView(tools, toolp);

        EditText amount = new EditText(this);
        amount.setSingleLine(true);
        amount.setInputType(2);
        amount.setHint("Jumlah (contoh: 1000)");
        amount.setPadding(16, 10, 16, 10);
        amount.setBackground(bg(Color.WHITE, 14));
        root.addView(amount, matchWrap());

        Spinner spinner = new Spinner(this);
        String[] choices = {"Coins", "Township Cash", "Gems"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, choices);
        spinner.setAdapter(adapter);
        LinearLayout.LayoutParams sp = matchWrap(); sp.topMargin = 10;
        root.addView(spinner, sp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button add = button("+ Tambah", 0xFF2D865A);
        Button subtract = button("− Kurangi", 0xFFB45B43);
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(50), 1);
        half.setMargins(0, dp(10), dp(5), 0); actions.addView(add, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(50), 1);
        half2.setMargins(dp(5), dp(10), 0, 0); actions.addView(subtract, half2);
        root.addView(actions, matchWrap());

        add.setOnClickListener(v -> changeBalance(spinner.getSelectedItemPosition(), amount, true));
        subtract.setOnClickListener(v -> changeBalance(spinner.getSelectedItemPosition(), amount, false));

        Button reset = button("Reset saldo demo", 0xFF536B60);
        LinearLayout.LayoutParams rp = matchWrap(); rp.topMargin = 12;
        root.addView(reset, rp);
        reset.setOnClickListener(v -> {
            balances = new long[]{250000, 5000, 2500};
            saveAndRefresh();
            Toast.makeText(this, "Saldo demo direset", Toast.LENGTH_SHORT).show();
        });

        TextView footer = text("Township Companion bukan produk resmi Playrix. Semua angka hanya tersimpan di aplikasi ini.", 11, 0xFF6F7B70, false);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(10, 22, 10, 8);
        root.addView(footer, matchWrap());
    }

    private void addWalletCard(int i) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18, 14, 18, 16);
        card.setBackground(bg(Color.WHITE, 20));
        LinearLayout.LayoutParams cp = matchWrap(); cp.topMargin = 9;
        root.addView(card, cp);

        TextView label = text(names[i], 15, 0xFF657568, true);
        card.addView(label);
        balanceViews[i] = text(format(balances[i]), 27, colors[i], true);
        LinearLayout.LayoutParams bp = matchWrap(); bp.topMargin = 4;
        card.addView(balanceViews[i], bp);
        TextView desc = text("Saldo simulasi lokal", 11, 0xFF879187, false);
        card.addView(desc);
    }

    private void changeBalance(int index, EditText input, boolean add) {
        String s = input.getText().toString().trim();
        if (s.isEmpty()) { input.setError("Masukkan jumlah"); return; }
        try {
            long n = Long.parseLong(s);
            if (n < 0) throw new NumberFormatException();
            if (add) balances[index] = Math.addExact(balances[index], n);
            else balances[index] = Math.max(0, balances[index] - n);
            saveAndRefresh();
            input.setText("");
            Toast.makeText(this, "Saldo demo diperbarui", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            input.setError("Jumlah tidak valid atau terlalu besar");
        }
    }

    private void saveAndRefresh() {
        SharedPreferences.Editor ed = prefs.edit();
        for (int i = 0; i < 3; i++) {
            ed.putLong(keys[i], balances[i]);
            if (balanceViews[i] != null) balanceViews[i].setText(format(balances[i]));
        }
        ed.apply();
    }

    private String format(long n) {
        return NumberFormat.getInstance(new Locale("id", "ID")).format(n);
    }

    private Button button(String label, int color) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(14);
        b.setAllCaps(false); b.setBackground(bg(color, 15));
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
