# Township Companion (Local Simulator)

Aplikasi Android demo untuk mencatat saldo simulasi Coins, Township Cash, dan Gems secara lokal.

## Batasan penting
- Tidak terhubung ke Township atau server Playrix.
- Tidak membaca atau mengubah data aplikasi Township.
- Tidak menghasilkan mata uang sungguhan.
- Saldo disimpan di SharedPreferences aplikasi Companion ini saja.

## Build APK
1. Ekstrak ZIP ini.
2. Buka folder `TownshipCompanion` melalui Android Studio.
3. Tunggu Gradle Sync selesai (memerlukan internet untuk mengunduh Android Gradle Plugin).
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

Persyaratan: Android Studio dengan JDK 17+ dan Android SDK Platform 35.
